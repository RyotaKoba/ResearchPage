# Master's Thesis Template
修士論文Abstractテンプレート．
神谷先輩が用いていたものをテンプレ化した．

# 中身
- img/ 画像を入れる．
- Masters_Abstract.cls クラスファイル．原則改変しない．（卒論とほぼ同じだが少し変わっている）
- reference.bib 参考文献を書くBibTeXファイル．詳しくはBibTeXの使い方を各自で調べて．ただし，Abstractの参考文献は数件しかないため，texファイルに直書きでも良い．
- Masters_Abstract.tex Abstract本体．

# 使い方の注意
`/section{}`と`/subsection{}`は使わずに，`/sec{}`と`/subsec{}`を用いる．

# 変更履歴
- 2018/11/09 神谷先輩の修論を拝借してテンプレート化した．多分ちゃんと動くはず． by ryorsk
